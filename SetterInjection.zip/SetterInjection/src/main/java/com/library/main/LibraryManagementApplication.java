package com.library.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.library.service.BookService;

public class LibraryManagementApplication {

    public static void main(String[] args) {

        // Load the Spring context
        ApplicationContext context =
                new ClassPathXmlApplicationContext("applicationContext.xml");

        // Get BookService bean
        BookService bookService =
                context.getBean("bookService", BookService.class);

        // Test constructor and setter injection
        bookService.displayService();

        // Close the context
        ((ClassPathXmlApplicationContext) context).close();
    }
}