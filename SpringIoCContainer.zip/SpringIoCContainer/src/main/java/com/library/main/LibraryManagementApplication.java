package com.library.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.library.service.BookService;

public class LibraryManagementApplication {

    public static void main(String[] args) {

        // Load the Spring IoC Container
        ApplicationContext context =
                new ClassPathXmlApplicationContext("applicationContext.xml");

        // Get BookService bean from the IoC Container
        BookService bookService =
                context.getBean("bookService", BookService.class);

        // Test the configuration
        bookService.displayService();

        // Close the Spring context
        ((ClassPathXmlApplicationContext) context).close();
    }
}